package com.technical.challenge.rise.model;

public class AverageDetails {

	private String avg800Margin;
	private String avg400Margin;
	private String avgMargin;
	
	private String avg800Time;
	private String avg400Time;
	
	private String avgSpeed800;
	private String avgSpeed400;
	private String avgSpeedofHorse;
	public String getAvg800Margin() {
		return avg800Margin;
	}
	public void setAvg800Margin(String avg800Margin) {
		this.avg800Margin = avg800Margin;
	}
	public String getAvg400Margin() {
		return avg400Margin;
	}
	public void setAvg400Margin(String avg400Margin) {
		this.avg400Margin = avg400Margin;
	}
	public String getAvgMargin() {
		return avgMargin;
	}
	public void setAvgMargin(String avgMargin) {
		this.avgMargin = avgMargin;
	}
	public String getAvg800Time() {
		return avg800Time;
	}
	public void setAvg800Time(String avg800Time) {
		this.avg800Time = avg800Time;
	}
	public String getAvg400Time() {
		return avg400Time;
	}
	public void setAvg400Time(String avg400Time) {
		this.avg400Time = avg400Time;
	}
	public String getAvgSpeed800() {
		return avgSpeed800;
	}
	public void setAvgSpeed800(String avgSpeed800) {
		this.avgSpeed800 = avgSpeed800;
	}
	public String getAvgSpeed400() {
		return avgSpeed400;
	}
	public void setAvgSpeed400(String avgSpeed400) {
		this.avgSpeed400 = avgSpeed400;
	}
	public String getAvgSpeedofHorse() {
		return avgSpeedofHorse;
	}
	public void setAvgSpeedofHorse(String avgSpeedofHorse) {
		this.avgSpeedofHorse = avgSpeedofHorse;
	}
	
	
	
}
