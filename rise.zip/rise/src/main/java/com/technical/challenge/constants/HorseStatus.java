package com.technical.challenge.constants;

public enum HorseStatus {
	STARTER, SCRATCHED,EMERGENCY
}
