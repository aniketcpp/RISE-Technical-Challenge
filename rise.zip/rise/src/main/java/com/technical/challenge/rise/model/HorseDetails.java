package com.technical.challenge.rise.model;

public class HorseDetails {

	private String horseId;
	private String horseName;
	private String speed;
	
	public String getHorseId() {
		return horseId;
	}
	public void setHorseId(String horseId) {
		this.horseId = horseId;
	}
	public String getHorseName() {
		return horseName;
	}
	public void setHorseName(String horseName) {
		this.horseName = horseName;
	}
	
	public String getSpeed() {
		return speed;
	}
	public void setSpeed(String speed) {
		this.speed = speed;
	}
	
	
}
