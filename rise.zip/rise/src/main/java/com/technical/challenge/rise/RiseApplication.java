package com.technical.challenge.rise;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RiseApplication {

	public static void main(String[] args) {
		SpringApplication.run(RiseApplication.class, args);
	}

}
