package com.technical.challenge.rise;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RiseApplicationTests {

	@Test
	void contextLoads() {
	}

}
